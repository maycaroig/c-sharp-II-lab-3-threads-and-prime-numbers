﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Lab03
{
	public class SafeQueue<T>
	{
		#region Fields
		private ReaderWriterLockSlim m_Lock = new ReaderWriterLockSlim();
		private Queue<T> m_Items = null;
		#endregion Fields

		#region Properties
		/// <summary>
		/// Gets the number of items in the queue
		/// </summary>
        public int Count
        { 
            get 
            { m_Lock.EnterReadLock();
                try 
                {
                    return m_Items.Count;
                }
                finally
                {
                    m_Lock.ExitReadLock(); 
                }
            }
        }

		#endregion Properties

		#region Constructors
		/// <summary>
		/// Creates a thread-safe queue with a maximum capacity
		/// </summary>
		/// <param name="maxItems">Maximum number of items that the queue can hold</param>
		public SafeQueue()
		{
            m_Items = new Queue<T>();
		}
		#endregion Constructors

		#region Methods
		/// <summary>
		/// Clears the queue
		/// </summary>
		public void Clear()
		{
            m_Lock.EnterWriteLock();
            try {
                m_Items.Clear();
            }
            finally
            {
                m_Lock.ExitWriteLock(); 
            }
		}

		/// <summary>
		/// Enqueues an item at the end of the queue.  If queue is at capacity, this call will block until a slot becomes available.
		/// </summary>
		/// <param name="item">Item to enqueue</param>
		public void Enqueue(T item)
		{
			m_Lock.EnterWriteLock();
            try 
            { 
                m_Items.Enqueue(item);
            } 
            finally 
            {
                m_Lock.ExitWriteLock();
            }
        
		}

		/// <summary>
		/// Attempts to retrieve a value from the queue
		/// </summary>
		/// <param name="value">Dequeued value</param>
		/// <returns>true if value found, false otherwise</returns>
		public bool TryDequeue(out T value)
		{
			value = default(T);
            m_Lock.EnterWriteLock();
            try 
            { 
                if (m_Items.Count > 0)
                {
                    value = m_Items.Dequeue();
                    return true; 
                }
            }
            finally 
            {
                m_Lock.ExitWriteLock();
            }
			return default(bool);
		}

		/// <summary>
		/// Attempts to peek from the queue
		/// </summary>
		/// <param name="value">Item at the front of the queue</param>
		/// <returns>true if value found, false otherwise</returns>
		public bool TryPeek(out T value)
		{
            value = default(T);
            m_Lock.EnterWriteLock();
            try
            {
                if (m_Items.Count > 0)
                {
                    value = m_Items.Peek();
                    return true;
                }
            }
            finally
            {
                m_Lock.ExitWriteLock();
            }
            return default(bool);
		}
		#endregion Methods
	}
}
